
const a = [
    {
      name: "Tik Tok",
      img: "/assets//img/apps/tiktok.jpg",
      href: "https://tiktok.com",
    },
    {
      name: "Youtube",
      img: "/assets//img/apps/youtube.png",
      href: "https://youtube.com",
    },
    {
      name: "Crazygames",
      img: "/assets//img/apps/crazygames.png",
      href: "https://crazygames.com",
    },
    {
      name: "Xbox Cloud Gaming",
      img: "/assets//img/apps/xbox.png",
      href: "https://xbox.com/play",
    },
    {
      name: "Figgs AI",
      img: "/assets/img/apps/fig.png",
      href: "https://www.figgs.ai/",
    },
    {
      name: "Spotify",
      img: "/assets//img/apps/spotify2.png",
      href: "https://spotify.com",
    },
    {
      name: "Now.gg",
      img: "/assets//img/apps/nowgg2.png",
      href: "https://now.gg",
    },
    {
      name: "VS Code",
      img: "/assets//img/apps/vscode2.png",
      href: "https://vscode.dev",
    },
    {
      name: "Coolmathgames",
      img: "/assets//img/apps/cmg2.png",
      href: "https://coolmathgames.com",
    },
    {
      name: "Discord",
      img: "/assets//img/apps/discord.jpg",
      href: "https://discord.com",
    },
    {
      name: "c.ai",
      img: "/assets//img/apps/cai.png",
      href: "https://c.ai",
    },
    {
      name: "Geforce Now",
      img: "/assets//img/apps/geforce.png",
      href: "https://play.geforcenow.com",
    },
    {
      name: "ChatGPT",
      img: "/assets//img/apps/chat.png",
      href: "https://chatgpt.com",
    },
    {
      name: "Amazon",
      img: "/assets//img/apps/amazon.png",
      href: "https://amazon.com",
    },
    {
      name: "Gmail",
      img: "/assets//img/apps/gmail.png",
      href: "https://gmail.com",
    },
    {
      name: "Github",
      img: "/assets//img/apps/github.png",
      href: "https://github.com",
    },
    {
      name: "Gamini",
      img: "/assets//img/apps/gem.png",
      href: "https://gemini.google.com",
    },
    {
      name: "Scratch",
      img: "/assets//img/apps/scratch.png",
      href: "https://scratch.mit.edu",
    },
    {
      name: "X",
      img: "/assets//img/apps/x.png",
      href: "https://x.com",
    },
    {
      name: "Twitch",
      img: "/assets//img/apps/twitch.png",
      href: "https://twitch.tv",
    },
    {
      name: "Youtube Music",
      img: "/assets//img/apps/youtubem.png",
      href: "https://music.youtube.com",
    },
    {
      name: "Replit",
      img: "/assets//img/apps/replit.png",
      href: "https://replit.com",
    },
    {
      name: "Pintrest",
      img: "/assets//img/apps/pintrest.png",
      href: "https://pinterest.com",
    },
    {
      name: "Duck Duck Go",
      img: "/assets//img/apps/ddg.png",
      href: "https://duckduckgo.com",
    },
    {
      name: "Bing",
      img: "/assets//img/apps/bing.png",
      href: "https://bing.com",
    },
    {
      name: "Yahoo Mail",
      img: "/assets//img/apps/yahoo.png",
      href: "https://mail.yahoo.com",
    },
  ];

export default a