# Ghost

A very cool games website :D

Join Our Discord server https://discord.gg/dbyDXfs5dN

<img src="/readme/ss.png">

# Features

A proxy
Lots of games
Cloaking
Theming
And More!

# Deploying

```
git clone https://github.com/The-Ghost-Network/Ghost-Node.git
cd Ghost-Node
npm i
npm start
```

# Credits

Credit to [Titanium Network](https://github.com/titaniumnetwork-dev) for Ultraviolet

Credit to [3kho](https://github.com/3kh0) for the games
